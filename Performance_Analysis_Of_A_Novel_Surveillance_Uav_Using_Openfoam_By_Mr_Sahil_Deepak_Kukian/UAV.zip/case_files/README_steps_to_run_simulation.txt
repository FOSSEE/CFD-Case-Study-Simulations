Follow steps below to run the case( Enter the below commands into the openFoam Console)

Step 1 surfaceFeatureExtract

Step 2  blockMesh

Step 3  cp -r 0.orig 0
 
Step 4 mpiexec -np 4 snappyHexMesh -overwrite

Step 5 decomposePar -copyZero

Step 6 mpiexec -np 4 patchSummary

Step 7 mpiexec -np 4 potentialFoam

Step 8 mpiexec -np 4 simpleFoam -parallel

step 9 reconstructParMesh

step 10 recontructPar


NOTE- If you dont have 8gb ram , then please reduce the mesh size 
or you can change the decomposePar dict file to reduce the processors used for snappyhexMesh
