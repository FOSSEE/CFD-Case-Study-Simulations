#!/bin/sh

ideasUnvToFoam Mesh_Fine.unv

createBaffles -overwrite

createPatch -overwrite

./Allrun


