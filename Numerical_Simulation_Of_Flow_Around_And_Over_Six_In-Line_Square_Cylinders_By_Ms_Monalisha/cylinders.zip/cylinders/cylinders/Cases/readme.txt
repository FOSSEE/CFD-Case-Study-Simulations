# Files for all cases are written in files of once case setup. Just need to uncomment the values for the cases which has to be run.

# polymesh has to be created by writing blockMesh command in the the case folder in the terminal.

#use pimpleFoam for all the cases.