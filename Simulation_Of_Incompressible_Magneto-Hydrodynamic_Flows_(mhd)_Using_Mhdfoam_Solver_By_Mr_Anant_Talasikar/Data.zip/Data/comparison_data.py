import os
import csv
import matplotlib.pylab as py
import numpy as np
from numpy import math
y=np.linspace(-1,1,101)
uth=[]
u_10B=[]
u_50B=[]
u_100B=[]
u_500B=[]
x1=[]
x2=[]
x3=[]
x4=[]
#for x in y:
 #a= (30*math.cosh(30))/(30*math.cosh(30)-math.sinh(30))
 #b= a*(1 - ( math.cosh(30*x) / math.cosh(30)))
with open ('Ux_data_10.csv','r') as csv1:
    r1 = csv.reader(csv1, delimiter = ',')
    for line in r1:
        i=line[0]
        j=line[1]
        u_10B.append(float(i))
        x1.append(float(j))
with open ('Ux_data_50.csv','r') as csv2:
    r2 = csv.reader(csv2, delimiter = ',')
    for line in r2:
        i=line[0]
        j=line[1]
        u_50B.append(float(i))
        x2.append(float(j))
with open ('Ux_data_100.csv','r') as csv3:
    r3 = csv.reader(csv3, delimiter = ',')
    for line in r3:
        i=line[0]
        j=line[1]
        u_100B.append(float(i))
        x3.append(float(j))
with open ('Ux_data_500.csv','r') as csv4:
    r4 = csv.reader(csv4, delimiter = ',')
    for line in r4:
        i=line[0]
        j=line[1]
        u_500B.append(float(i))
        x4.append(float(j))
py.plot(u_10B, x1, label ='Ha=10') 
py.plot(u_50B, x2, label = 'Ha=50')
py.plot(u_100B, x3, label ='Ha=100')
py.plot(u_500B, x4, label ='Ha=500')
py.ylabel('U(x)', fontsize=20)
py.xlabel('arc-length', fontsize=20)
py.title('Effect of Magnetic field on flow velocity', fontsize=25)
py.legend(fontsize=15)
py.show()