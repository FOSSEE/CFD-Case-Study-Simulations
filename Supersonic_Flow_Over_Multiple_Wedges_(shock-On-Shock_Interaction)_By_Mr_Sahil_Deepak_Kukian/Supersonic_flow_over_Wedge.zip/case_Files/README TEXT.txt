To run this simualtion 

1.fluentMeshToFoam wedge_structured.msh (convert mesh into Openfoam Format and edit patch values is constant/polymesh/boundary)
2.decomposePar 
3.mpiexec -np 4 rhoCentralFoam -parallel
4 mpiexec -np 4 reconstructPar 

view the Results by entering "paraFoam"  in the console 

IF you want to run a case with different time Steps or different Inlet condition Please delete all the timeStep Data other than 0
and make necessary changes in the respective files.