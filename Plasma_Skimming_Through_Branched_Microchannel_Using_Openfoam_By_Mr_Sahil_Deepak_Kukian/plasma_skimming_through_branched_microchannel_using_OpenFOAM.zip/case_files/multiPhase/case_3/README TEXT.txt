To run this simualtion 

1.fluentMeshToFoam plasma_twophase.msh (convert mesh into Openfoam Format and edit patch values is constant/polymesh/boundary)
2.decomposePar 
3.mpiexec -np 6 twoPhaseEulerFoam -parallel 
4 mpiexec -np 6 reconstructPar

view the Results by entering "paraFoam"  in the console 
Change the number of processors according to your system specifications and also make
necessary changes to the decomposePar dict file 
IF you want to run a case with different time Steps or different Inlet condition Please delete all the timeStep Data other than 0
and make necessary changes in the respective files.

