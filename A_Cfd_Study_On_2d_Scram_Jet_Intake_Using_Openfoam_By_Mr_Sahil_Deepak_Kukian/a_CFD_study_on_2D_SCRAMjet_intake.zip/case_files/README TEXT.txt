To run this simualtion 

1.fluentMeshToFoam scramjet_intake.msh (convert mesh into Openfoam Format and edit patch values is constant/polymesh/boundary)
2.decomposePar 
3.mpiexec -np 6 rhoCentralFoam -parallel
4 mpiexec -np 6 reconstructPar 

view the Results by entering "paraFoam"  in the console 
Change the number of processors according to your system specifications and also make
necessary changes to the decomposePar dict file 
IF you want to run a case with different time Steps or different Inlet condition Please delete all the timeStep Data other than 0
and make necessary changes in the respective files.

Note** 
To run different cases, make the necessary changes to the U dict as given below for different Mach no 
Case_1_Mach4.5 - change U to uniform (1287.19533  0 0)
Case_2_Mach5.5 - change U to uniform (1573.23873  0 0)
Case_3_Mach6.5 - change U to uniform (1859.28214  0 0)
Case_3_Mach7.5 - change U to uniform (2145.32555  0 0)
Case_5_AOA-2   - change U to uniform (1858.1495 -64.888 0)
Case_6_AOA2    - change U to uniform (1858.1495 64.888 0) 