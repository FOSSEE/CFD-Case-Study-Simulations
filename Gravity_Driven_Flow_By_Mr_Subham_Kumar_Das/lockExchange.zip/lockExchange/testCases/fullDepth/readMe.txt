To run the case,

navigate to the case directory, choose the set of fluids you want to simulate by editing the transportProperties file in the constant directory.

Open the terminal and navigate to the case directory.

Execute the 'blockMesh' command in the terminal to generate the mesh.

Execute the 'setFields' command in the terminal to set one of the fluids in a section of the computational domain, at the initial time.

Execute the 'interFoam' command in the terminal to run the simulation.

Default case : Freshwater-saline water lock exchange flow case. Simulation runs for 5 seconds and data is recorded after 0.1 seconds. 


