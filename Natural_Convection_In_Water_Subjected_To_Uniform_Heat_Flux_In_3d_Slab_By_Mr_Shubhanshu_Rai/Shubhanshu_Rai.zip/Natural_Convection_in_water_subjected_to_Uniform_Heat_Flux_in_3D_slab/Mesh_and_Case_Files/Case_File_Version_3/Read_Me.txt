




                                  1)   Boussinesq Aprroximation is not used in this case
                                
                                  2)   Thermophysical Properties are assumed as constant 