



                         This case is similar to base case  having same boundary conditions, only difference is that thermophysical property density, specific heat 
                      
                         is taken as function of absolute temperature



                                                                Density = a + bT+cT^2+dT^3 +eT^4 +fT^5 +gT^6 +hT^7

                                                                Specific Heat = A + BT+CT^2+DT^3 +ET^4 +FT^5 +GT^6 +HT^7