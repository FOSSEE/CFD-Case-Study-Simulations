 Use the following commands in terminal

0) nano filename.foam 
0.1) ctrl +o
0.2)  ctrl +x

1)   buoyantPimpleFoam > log.plate

2)    ./plot 

//Since case  files contains polymesh files already, so there is no need to run gmshToFoam command.

If u wants to use then delete polymesh folder and  use following commands in terminal

3)    GmshToFoam plate

after typing above command go to constant/polymesh/boundary

change the patch type to wall for every faces.

 then run command 0 to  2 mentioned above 


ABOVE MENTIONED METHOD IS APPLICABLE TO EACH VERSION OF CASE FILES