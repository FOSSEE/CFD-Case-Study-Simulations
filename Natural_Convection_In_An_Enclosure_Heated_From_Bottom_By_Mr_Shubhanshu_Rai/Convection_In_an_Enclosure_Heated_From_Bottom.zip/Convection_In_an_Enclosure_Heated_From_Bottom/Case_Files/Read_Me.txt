
 


                                  To run the simulation use following methodlogy


                                  1) Run the "Allrun" file, script is written within it.
