# Create polymesh file by running blockMesh command in the terminal.

# Select either case 1 ot case 2 by following commands in sprayCloudProperties file.

# To simulate the case, use sprayFoam command. 