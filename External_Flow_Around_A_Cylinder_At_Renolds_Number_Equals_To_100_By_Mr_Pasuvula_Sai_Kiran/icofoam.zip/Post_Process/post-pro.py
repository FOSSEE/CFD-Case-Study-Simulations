

import numpy as np
import scipy.signal as signal
import matplotlib.pyplot as plt

# # Read Results
data = np.loadtxt(r'G:\1tut\icofoam\re100\postProcessing\forceCoeffs\0\forceCoeffs.dat', skiprows=0)

L       = 2           # L = D - Diameter
V       = 1           # Velocity
time    = data[:,0]
Cd      = data[:,2]
Cl      = data[:,3]
Re = 100
del data

# Compute FFT

N       = len(time)
dt      = time[2] - time[1]


# no. of points in the fft
nmax=512      
# freq, Cd_amp = signal.welch(Cd, 1./dt, nperseg=nmax)
freq, Cl_amp = signal.welch(Cl, 1./dt, nperseg=nmax)



# Find the index corresponding to max amplitude
Cl_max_fft_idx = np.argmax(abs(Cl_amp))  
freq_shed      = freq[Cl_max_fft_idx ]
St             = freq_shed * L / V
#St_em_1         = 0.2684-(1.0356/Re**0.5) #  for re>150
St_em          = 0.198*(1-19.7/Re)  # for 50<re>150

print("Vortex shedding freq: %.3f [Hz]" % (freq_shed))
print("Strouhal Number: %.3f" % (St))
print("empirical Strouhal Number: %.3f" % (St_em))
#print("empirical Strouhal Number: %.3f" % (St_em_2))

plt.plot(freq, Cl_amp)    
plt.grid(True) 
plt.title('freq vs amplitute')
plt.xlabel('freq')
plt.ylabel('amplitude')
plt.show() 


plt.plot(time,Cl)
plt.grid(True)
plt.title('time vs coefficient of lift')
plt.xlabel('time')
plt.ylabel('coefficient of lift')
plt.show()

plt.plot(time,Cd)
plt.grid(True)
plt.title('time vs coefficient of drag')
plt.xlabel('time')
plt.ylabel('coefficient of drag')
plt.show()
