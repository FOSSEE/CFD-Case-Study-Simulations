1. The folder "mhdturbFoam" is a solver. It needs to be copied to solver directory in /electromagnetics.
2. Once copied, it needs to be compiled. Then only, it can be used.