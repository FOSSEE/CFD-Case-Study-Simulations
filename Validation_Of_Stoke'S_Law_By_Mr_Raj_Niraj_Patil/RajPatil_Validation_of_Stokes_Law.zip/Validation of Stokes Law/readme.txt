
Data folder contains velocity files as well as paraview files for all the cases.
Before running any simulation, user must paste correct velocity file in 0 folder.
Case folder contains tutorial files.

run 

fluent3DMeshToFoam stokesLaw.msh
simpleFoam