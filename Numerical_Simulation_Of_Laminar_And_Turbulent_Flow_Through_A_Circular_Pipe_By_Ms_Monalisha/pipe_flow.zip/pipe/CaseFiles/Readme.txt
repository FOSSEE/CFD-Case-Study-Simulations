# Files for all cases are written in files of once case setup. Just need to uncomment the values for the cases which has to be run.

# polymesh has to be created by writing blockMesh command in the the case folder in the terminal.

# Just use the icoFoam command for Case 01 and pimpleFoam command for Case 02, Case 03 and Case 04 to begin the simulation.
