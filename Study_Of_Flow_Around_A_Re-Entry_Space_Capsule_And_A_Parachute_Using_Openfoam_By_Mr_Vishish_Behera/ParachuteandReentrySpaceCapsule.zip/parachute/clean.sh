#!/bin/sh

rm test.msh
rm -r case/*00
rm -r case/postProcessing
rm -r case/constant/polyMesh
rm case/case.OpenFOAM

