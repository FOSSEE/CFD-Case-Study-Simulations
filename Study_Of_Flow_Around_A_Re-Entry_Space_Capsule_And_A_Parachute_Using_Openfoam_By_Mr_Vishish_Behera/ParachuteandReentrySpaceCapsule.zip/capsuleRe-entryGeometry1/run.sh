#!/bin/sh
set -e
gmsh mesh.geo -3 -o test.msh
gmshToFoam test.msh -case case
changeDictionary -case case
sonicFoam -case case

