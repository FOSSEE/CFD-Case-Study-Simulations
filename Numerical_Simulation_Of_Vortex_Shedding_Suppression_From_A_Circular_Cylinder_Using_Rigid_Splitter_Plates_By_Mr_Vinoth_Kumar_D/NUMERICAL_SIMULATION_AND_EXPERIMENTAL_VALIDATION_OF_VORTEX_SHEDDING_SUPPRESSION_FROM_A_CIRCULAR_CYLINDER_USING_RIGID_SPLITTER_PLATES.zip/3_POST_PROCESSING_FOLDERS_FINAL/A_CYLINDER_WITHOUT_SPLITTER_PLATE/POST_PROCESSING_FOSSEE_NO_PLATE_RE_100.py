#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Sun Sep 22 22:24:43 2019

@author: user
"""
import numpy as np
import pylab as pyl
import matplotlib.pyplot as plt
import csv as csv
import pandas as pd
#from scipy.fftpack import fft
from numpy.fft import fft
from itertools import groupby
import xlrd
import math
import math as math
import numpy as np
import scipy.signal as signal
import matplotlib.pyplot as plt
#data = np.genfromtxt('FORCECOEFFS.csv',delimiter=',')
#print(data)
IMPORT_DATA = np.genfromtxt('forceCoeffs.dat',unpack=True, usecols=[0,1,2,3,4,5])
#print(IMPORT_DATA)
Cl=IMPORT_DATA[3]
#print(Cl)
TIME=IMPORT_DATA[0]
#print(TIME)
#print(type(Cl))
#print(np.size(Cl))
Cl1=[]

for i in range(np.size(Cl)): 
    Cl1.append(Cl[i]) 
signal_values1= fft(Cl1)
fftvalues=np.fft.fftshift(signal_values1)
#print(signal_values1)
#print(fftvalues)


plt.figure(1)
plt.plot(TIME,Cl1,'g')
plt.xlabel('Time')
plt.ylabel('Cl')
plt.grid()

plt.figure(2)
freq, Cl_amp = signal.welch(Cl, 1./0.1, nperseg=20000)
#print(freq)
#print(Cl_amp)
plt.plot(freq, Cl_amp)
plt.xlabel('Frequency')
plt.ylabel('Amplitude')
plt.show() 
Cl_max_fft_idx = np.argmax(abs(Cl_amp))  
#print(Cl_max_fft_idx)
freq_shed      = freq[Cl_max_fft_idx ]
print("THE FREQUENCY OF VORTICES PER SECOND IS")
print(freq_shed)
St=(freq_shed*0.005/0.0178)
print("THE STROUHAL NUMBER IS")
print(St)


Cd=IMPORT_DATA[2]
#print(Cd)
TIME=IMPORT_DATA[0]
#print(TIME)
#print(type(Cl))
#print(np.size(Cl))
Cd1=[]

for i in range(np.size(Cd)): 
    Cd1.append(Cd[i]) 
signal_values11= fft(Cd1)
fftvalues1=np.fft.fftshift(signal_values11)
#print(signal_values11)
#print(fftvalues1)


plt.figure(3)
plt.plot(TIME,Cd1,'b')
plt.xlabel('Time')
plt.ylabel('Cd')
plt.grid()