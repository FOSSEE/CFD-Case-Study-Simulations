# Choose blockmeshDict file as per the case i.e. every case has different blockMeshDict file.

# Create polymesh.

# Finally, use solver interPhaseChaseFoam.