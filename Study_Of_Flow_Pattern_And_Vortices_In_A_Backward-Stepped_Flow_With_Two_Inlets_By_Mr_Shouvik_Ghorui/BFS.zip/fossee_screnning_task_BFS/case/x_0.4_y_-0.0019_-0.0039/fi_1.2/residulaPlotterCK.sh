set logscale y
set title "Residuals" font "serif,20"
set ylabel 'Residual' font "serif,20"
set xlabel 'Iteration' font "serif,20"
set tics font "serif,15";
set key font "serif,20"; set key spacing 3
filename='log.log'
plot "< cat log.log | grep 'Solving for p'      | cut -d' ' -f9 | tr -d ','" title 'p' with lines lc rgb "yellow",\
	"< cat log.log | grep 'Solving for Ux'     | cut -d' ' -f9 | tr -d ','" title 'Ux'  with lines lc rgb "red",\
	"< cat log.log | grep 'Solving for Uy'     | cut -d' ' -f9 | tr -d ','" title 'Uy' with lines lc rgb "blue"
pause 10
reread
